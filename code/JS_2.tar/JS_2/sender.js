/**
 * @Author: Ribault Pierre <cawo>
 * @Date:   2018-02-19T16:51:34+01:00
 * @Email:  me@ribaultpierre.fr
 * @Last modified by:   cawo
 * @Last modified time: 2018-02-19T18:06:56+01:00
 */


 var threshold = .0015;
 //taille de 8M0
 var buffer_size = 1024 * 8192;
 var line_length =Math.pow(2,12);
 var current;
 var probe_buffer = new ArrayBuffer(buffer_size);
 var prime_buffer = new ArrayBuffer(buffer_size);
 var probe_view = new DataView(probe_buffer);
 var prime_view = new DataView(prime_buffer);
 var iteration = 1000;
 var x = 4;
var toto;
 function probe()
 {
 for (var j = 0; j < ((buffer_size) / line_length); j++) {
   current = probe_view.getUint32(j * line_length);
 }
 //sleep(0.001)

 }

 function prime()
 {
    for (var j = 0; j < ((buffer_size) / line_length); j++) {
     current = prime_view.getUint32(x);
   }
   sleep(0.0075)

   }
   function sleep(delay) {
   	var start = window.performance.now();
   	while (window.performance.now() < start + delay);
   }


for(var i = 0;i < iteration;i++)
{
  /*
  if( i % 2 == 0){;

  prime();
}
else {
  probe();
}
*/
if(i % 2 == 0){
prime();
}
else {
  probe();
}

console.log("test prime = " + diffTime1 * 10000);
}

/**
 * @Author: Ribault Pierre <cawo>
 * @Date:   2018-02-19T16:51:46+01:00
 * @Email:  me@ribaultpierre.fr
 * @Last modified by:   cawo
 * @Last modified time: 2018-02-19T18:12:12+01:00
 */

 var threshold = .0015;
 //taille de 8M0
 var buffer_size = 1024 * 8192;
 var line_length =Math.pow(2,12);
 var current;
 var probe_buffer = new ArrayBuffer(buffer_size);
 var prime_buffer = new ArrayBuffer(buffer_size);
 var probe_view = new DataView(probe_buffer);
 var prime_view = new DataView(prime_buffer);
 var iteration = 1000;
 var x = 0;


function faireRien()
{
  for (var j = 0; j < ((buffer_size) / line_length); j++) {
//    Math.pow(130,48);

  }
}
function sleep(delay) {
	var start = window.performance.now();
	while (window.performance.now() < start + delay);
}

for (var j = 0; j < ((buffer_size) / line_length); j++) {
  current = probe_view[j * line_length] = (j * line_length);
}
 for(var i = 0;i <iteration;i++){
 //faireRien();
 //sleep(0.052);
  var startTime1 = window.performance.now()
   current =  prime_view.getUint32(x);
   var diffTime1 = window.performance.now() - startTime1;

   console.log("test prime = " + diffTime1);
   var startTime2 = window.performance.now();
 	current = prime_view.getUint32(x);
 	var diffTime2 = window.performance.now() - startTime2;
  console.log("test 2 probe = " + diffTime2);

 }
